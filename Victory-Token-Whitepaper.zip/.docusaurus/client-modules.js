export default [
  require('E:\\Victory Doc\\Victory-Token-Whitepaper\\node_modules\\infima\\dist\\css\\default\\default.css'),
  require('E:\\Victory Doc\\Victory-Token-Whitepaper\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages'),
  require('E:\\Victory Doc\\Victory-Token-Whitepaper\\node_modules\\@docusaurus\\theme-classic\\lib\\admonitions.css'),
  require('E:\\Victory Doc\\Victory-Token-Whitepaper\\src\\css\\custom.css'),
];
