---
sidebar_position: 2
---

# Android


## Step 1. Open Trust Wallet and Click DApps

- Just hit the icon....


![1](/img/tutorial/phone/01.jpg)


## Step 2. Paste the Presale Address Into The Bar

- Copy it from our chat etc.

![1](/img/tutorial/phone/02.jpg)



![1](/img/tutorial/phone/04.jpg)

## Step 3. Now Hit Enter Or Hit The Checkmark 

- Tap the checkmark in the bottom right

![1](/img/tutorial/phone/05.jpg)


## Step 4. Switch Your Icon To BNB

- Hit the Diamond in the top right

![1](/img/tutorial/phone/06.jpg)

## Step 6. Make Sure You Hit Smart Chain

- Smart chain is BNB

![1](/img/tutorial/phone/07.jpg)

## Step 6. Now Hit Connect

- Press the pink connect button

![1](/img/tutorial/phone/08.jpg)




## Step 7. Press TrustWallet

- Just smack the trustwallet icon

![1](/img/tutorial/phone/09.jpg)


## Step 8. You Should See Numbers And Letters

- It will be your own personal wallet address

![1](/img/tutorial/phone/10.jpg)

## Step 9. Scroll Down To Make A BUY!

- Scroll all the way down until you see the buy button

![1](/img/tutorial/phone/11.jpg)





 

:::tip ALERT!

After you hit buy, you must wait until the PRESALE is over to claim what you just bought.

:::