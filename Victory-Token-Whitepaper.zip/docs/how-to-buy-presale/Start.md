---
sidebar_position: 1
---

# Intro

![1](/img/tutorial/pink.png)

[Crypto.com](http://www.crypto.com) is a super easy exchange to get **BNB** from.


:::tip TIP!
Before you can buy from **ANY** Presale you must have **Smart Chain(BNB)** in your wallet!
:::

