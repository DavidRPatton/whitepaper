---
sidebar_position: 2
---

# Apple
Apple doesn't have DAapps. So you can't make buys like someone with an android can. You must use your browser.
- I am using an android to show you this. So my browser may look different.

## Step 1. Open Your Browser And Paste The Presale Link

- It doesn't matter what browser you use. (I like Chrome)


![1](/img/tutorial/phone/110.jpg)



## Step 2. Switch Your Icon To BNB

- Hit the Diamond in the top right

![1](/img/tutorial/phone/111.jpg)


## Step 3. Make Sure You Hit Smart Chain

- Smart chain is BNB

![1](/img/tutorial/phone/112.jpg)

## Step 4. Now Hit Connect

- Press the pink connect button

![1](/img/tutorial/phone/113.jpg)



## Step 5. Press WalletConnect

- Just smack the walletconnect icon

![1](/img/tutorial/phone/114.jpg)


## Step 6. Press Connect

- .....

![1](/img/tutorial/phone/115.jpg)

## Step 7. Press Metamask

- Just HIT IT!

![1](/img/tutorial/phone/116.jpg)

## Step 8. Verify Its Your Wallet By Pressing Connect

- Please Verify!

![1](/img/tutorial/phone/117.jpg)


## Step 9. You Should Now See A Connected Message

- Connected To Victory Token Presale

![1](/img/tutorial/phone/118.jpg)

## Step 10. Go Back To Your Browser And Make Sure You See Your Connected Wallet

- There should be numbers and letters

![1](/img/tutorial/phone/119.jpg)
 

## Step 10. Your Ready To Buy!

- Scroll down until you see a buy button
- Put in your number of BNB and click BUY
- Once you put the number in you should see how many tokens you will get back

![1](/img/tutorial/phone/120.jpg)

:::tip ALERT!

After you hit buy, you must wait until the PRESALE is over to claim what you just bought.

:::