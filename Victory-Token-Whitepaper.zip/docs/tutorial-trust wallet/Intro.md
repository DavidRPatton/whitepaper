---
sidebar_position: 1
---
# Intro

How To Install Metamask

More Information at: **https://community.trustwallet.com/t/how-to-create-a-multi-coin-wallet/41**.

### What you'll need

- Desktop/Laptop Computer
- Android Phone/Device
- Apple Phone/Device



## Getting Started

Go to **https://trustwallet.com** and select from Android or iOS for mobile application. 

You can also go directly to Google Play store, or Apple App Store.


