---
sidebar_position: 1
---
# Intro

How To Install Metamask

More Information at: **https://metamask.io/faqs**.

### What you'll need

- Desktop/Laptop Computer
- Android Phone/Device
- Apple Phone/Device



## Getting Started

Go to **https://metamask.io** and select from Android or iOS for mobile application and select Chrome for desktop. 

You can also go directly to the Chrome store, Google Play store, or Apple App Store.


